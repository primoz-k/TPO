/** Automatically generated file. DO NOT MODIFY */
package com.fri.tpo.btc;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}